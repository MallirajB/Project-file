﻿using SpanEmployee.Core.IRepository;
using SpanEmployee.Core.IServices;
using SpanEmployee.Core.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace SpanEmployee.Services.Services
{
    public class Service : IServices
    {
        IRepository _repository;

        public Service(IRepository repository)
        {
            _repository = repository;
        }

        public void InsertOrUpdate(EmployeeModel model)
        {
            _repository.InsertOrUpdate(model);

        }

        public List<EmployeeModel> ListEmployee()
        {
           return _repository.ListEmployee();
        }
        public EmployeeModel Retrieve(int id)
        {
            return _repository.Retrieve(id);
        }
        public void Delete(int? id)
        {
            _repository.Delete(id);
        }


        public bool InsertEmp(EmployeeModel model)
        {
            return _repository.InsertEmp(model);
        }
        public bool UpdateEmp(EmployeeModel model)
        {
            return _repository.UpdateEmp(model);
        }

    }
}
