﻿using Microsoft.AspNetCore.Mvc;
using SpanEmployee.Core.IServices;
using SpanEmployee.Core.Model;

namespace SpanEmployee.Controllers.SpanEmployee
{
    public class SpanEmployeeController : Controller
    {
        IServices _Iservices;

        public SpanEmployeeController(IServices Iservices)
        {
            _Iservices = Iservices;
        }

        public IActionResult Index()
        {
            return View();
        }

        //Insert
        [HttpPost]

        public IActionResult Index(EmployeeModel model)
        {
            if (ModelState.IsValid)
            {
                _Iservices.InsertOrUpdate(model);
                return RedirectToAction("ListView");
            }
            return View(model);
        }
        public IActionResult ListView()
        {
            var ListData = _Iservices.ListEmployee();
            return View(ListData);
        }

        public IActionResult Delete(int id)
        {
            if (id < 0)
            {
                return RedirectToAction("ListView");
            }
            var dbdata = _Iservices.Retrieve(id);
            return View(dbdata);
        }
        [HttpPost]
        public IActionResult Delete(int? id)
        {
            if (ModelState.IsValid)
            {
                _Iservices.Delete(id);
                return RedirectToAction("ListView");
            }
            return RedirectToAction("Delete");
        }
        public IActionResult Edit(int id)
        {
            if (id < 0)
            {
                return RedirectToAction("ListView");
            }
            var retrieve = _Iservices.Retrieve(id);
            return View(retrieve);
        }

        [HttpPost]
        public IActionResult Edit(EmployeeModel model)
        {
            if (ModelState.IsValid)
            {
                _Iservices.InsertOrUpdate(model);
                return RedirectToAction("ListView");

            }
            return View(model);
        }

        public IActionResult Employee()
        {
            return View();
        }

        [HttpPost]
        public JsonResult InsertEmp(EmployeeModel model)
        {
            var result = _Iservices.InsertEmp(model);
            return Json(result);
        }
    }
}
