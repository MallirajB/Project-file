﻿using SpanEmployee.Core.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace SpanEmployee.Core.IServices
{
    public interface IServices
    {
        void InsertOrUpdate(EmployeeModel model);
        List<EmployeeModel> ListEmployee();
        EmployeeModel Retrieve(int id);
        void Delete(int? id);
        bool InsertEmp(EmployeeModel model);
        bool UpdateEmp(EmployeeModel model);
    }
}
