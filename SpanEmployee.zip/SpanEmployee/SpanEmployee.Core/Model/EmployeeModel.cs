﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace SpanEmployee.Core.Model
{
    public class EmployeeModel
    {
        [Key]
        public int EmpId { get; set; }
        [Required(ErrorMessage = "Please Enter the First name")]
        [Display(Name ="First Name :")]
        public string EmpFirstName { get; set; }
        [Required(ErrorMessage = "Please Enter the Second name")]
        [Display(Name = "Second Name :")]
        public string EmpSecondName { get; set; }
        [Required(ErrorMessage = "Please Enter the Designation")]
        [Display(Name = "Designation :")]
        public string Designation { get; set; }
        [Required(ErrorMessage = "Please Enter the Gender")]
        [Display(Name = "Gender :")]
        public string Gender { get; set; }
        [Display(Name = "Joining Date :")]
        [DataType(DataType.Date)]
        public DateTime? joiningdate { get; set; }
        [Display(Name ="Salary :")]
        public decimal? Salary { get; set; }
        [Display(Name ="Mobile No :")]
        public string MobileNo { get; set; }
        public bool? is_Deleted { get; set; }
    }
}
