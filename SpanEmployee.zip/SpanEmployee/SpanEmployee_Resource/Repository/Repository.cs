﻿using SpanEmployee.Core.IRepository;
using SpanEmployee.Core.Model;
using SpanEmployee.Resource;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SpanEmployee_Resource.Repository
{
    public class Repository : IRepository 
    {
        public void InsertOrUpdate(EmployeeModel model)
        {
            try
            {
                Mas_SpanEmp Employee = new Mas_SpanEmp();
                if (model != null)
                {
                    using (var Entity = new Fresher_2019Context())
                    {
                        var dbdata = Entity.Mas_SpanEmp.Where(x => x.EmpId == model.EmpId).SingleOrDefault();

                        if (dbdata == null)
                        {
                            Employee.EmpFirstName = model.EmpFirstName;
                            Employee.EmpSecondName = model.EmpSecondName;
                            Employee.Designation = model.Designation;
                            Employee.Gender = model.Gender;
                            Employee.joiningdate = model.joiningdate;
                            Employee.Salary = model.Salary;
                            Employee.MobileNo = model.MobileNo;

                            Entity.Mas_SpanEmp.Add(Employee);

                        }
                        else
                        {
                            dbdata.EmpId = model.EmpId;
                            dbdata.EmpFirstName = model.EmpFirstName;
                            dbdata.EmpSecondName = model.EmpSecondName;
                            dbdata.Designation = model.Designation;
                            dbdata.Gender = model.Gender;
                            dbdata.joiningdate = model.joiningdate;
                            dbdata.Salary = model.Salary;
                            dbdata.MobileNo = model.MobileNo;

                            Entity.Mas_SpanEmp.Update(dbdata);

                        }
                        Entity.SaveChanges();
                    }

                }
            }
            catch (Exception)
            {

                throw;
            }
           

        }
        public List<EmployeeModel> ListEmployee()
        {
            try
            {
                List<EmployeeModel> data = new List<EmployeeModel>();

                using (var Entity = new Fresher_2019Context())
                {
                    var dbdata = Entity.Mas_SpanEmp.Where(x => x.is_Deleted == false).ToList();

                    if (dbdata != null)
                    {
                        foreach (var item in dbdata)
                        {
                            EmployeeModel emp = new EmployeeModel();
                            emp.EmpFirstName = item.EmpFirstName;
                            emp.EmpSecondName = item.EmpSecondName;
                            emp.Designation = item.Designation;
                            emp.Gender = item.Gender;
                            emp.joiningdate = item.joiningdate;
                            emp.Salary = item.Salary;
                            emp.MobileNo = item.MobileNo;
                            data.Add(emp);
                        }
                    }
                    
                    return data.ToList();
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        public EmployeeModel Retrieve(int id)
        {
            EmployeeModel emp = new EmployeeModel();
            using (var Entity = new Fresher_2019Context())
            {
                var dbdata = Entity.Mas_SpanEmp.Find(id);
                emp.EmpId = dbdata.EmpId;
                emp.EmpFirstName = dbdata.EmpFirstName;
                emp.EmpSecondName = dbdata.EmpSecondName;
                emp.Designation = dbdata.Designation;
                emp.Gender = dbdata.Gender;
                emp.joiningdate = dbdata.joiningdate; 
                emp.Salary = dbdata.Salary;
                emp.MobileNo = dbdata.MobileNo;
                Entity.SaveChanges();

            }
            return emp;
            
        }

        public void Delete(int? id)
        {
            if (id.HasValue)
            {
                using (var Entity = new Fresher_2019Context())
                {
                    var dbdata = Entity.Mas_SpanEmp.Where(x => x.EmpId == id).SingleOrDefault();

                    dbdata.is_Deleted = true;
                    Entity.SaveChanges();
                }       
            }
        }

        public bool InsertEmp(EmployeeModel model)
        {
            try
            {
                using (var entity = new Fresher_2019Context())
                {
                    Mas_SpanEmp Span = new Mas_SpanEmp();

                    Span.EmpFirstName = model.EmpFirstName;
                    Span.EmpSecondName = model.EmpSecondName;
                    Span.Designation = model.Designation;
                    Span.Gender = model.Gender;
                    Span.joiningdate = model.joiningdate;
                    Span.Salary = model.Salary;
                    Span.MobileNo = model.MobileNo;

                    entity.Mas_SpanEmp.Add(Span);
                    entity.SaveChanges();
                }

                return true;

            }
            catch (Exception)
            {

                return false;
            }
        }

        public bool UpdateEmp(EmployeeModel model)
        {
            try
            {
                using (var Entity = new Fresher_2019Context())
                {
                    Mas_SpanEmp Employee = new Mas_SpanEmp();

                    var dbdata = Entity.Mas_SpanEmp.Where(x => x.EmpId == model.EmpId).SingleOrDefault();

                    dbdata.EmpId = model.EmpId;
                    dbdata.EmpFirstName = model.EmpFirstName;
                    dbdata.EmpSecondName = model.EmpSecondName;
                    dbdata.Designation = model.Designation;
                    dbdata.Gender = model.Gender;
                    dbdata.joiningdate = model.joiningdate;
                    dbdata.Salary = model.Salary;
                    dbdata.MobileNo = model.MobileNo;

                    Entity.Mas_SpanEmp.Update(dbdata);

                    Entity.SaveChanges();

                }
                return true;
            }
            catch (Exception)
            {

                return false;
            }
        }
    }
}
