﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using SpanEmployee.Core.IRepository;
using SpanEmployee.Core.IServices;
using SpanEmployee.Services.Services;
using SpanEmployee_Resource.Repository;
using System;
using System.Collections.Generic;
using System.Text;

namespace SpanEmployee.utility
{
    public static class DIResolver
    {
        public static void ConfigureServices(IServiceCollection services)
        {
            services.AddTransient<IHttpContextAccessor, HttpContextAccessor>();

            services.AddScoped<IServices, Service>();

            services.AddScoped<IRepository, Repository>();
        }
    }
}
