﻿using FSampleStudent.Core.IRepository;
using FSampleStudent.Core.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FSampleStudent.Resource.Repository
{
    public class Repository : IRepository
    {

        public void saveOrEditStudents(StudentModel model)
        {
            Mas_Student students = new Mas_Student();
            if (model != null)
            {
                using (var entities = new Fresher_2019Context())
                {

                    var dbstuden = entities.Mas_Student.Where(x => x.StudentId == model.StudentId).SingleOrDefault();
                    if (dbstuden == null)
                    {
                        students.StudentFirstName = model.StudentFirstName;
                        students.StudentSecondName = model.StudentSecondName;
                        students.Department = model.Department;
                        students.Gender = model.Gender;
                        students.joiningdate = model.joiningdate;

                        entities.Mas_Student.Add(students);
                    }
                    else
                    {
                        dbstuden.StudentFirstName = model.StudentFirstName;
                        dbstuden.StudentSecondName = model.StudentSecondName;
                        dbstuden.Department = model.Department;
                        dbstuden.Gender = model.Gender;
                        dbstuden.joiningdate = model.joiningdate;

                        entities.Mas_Student.Update(dbstuden);
                    }
                    entities.SaveChanges();
                }

            }
        }
       
        public StudentModel DeleteOrEdit(int id)
        {
            StudentModel model = new StudentModel();
            using (var entities = new Fresher_2019Context())
            {
                var dbstudent = entities.Mas_Student.Find(id);
                model.StudentId = dbstudent.StudentId;
                model.StudentFirstName = dbstudent.StudentFirstName;
                model.StudentSecondName = dbstudent.StudentSecondName;
                model.Gender = dbstudent.Gender;
                model.Department = dbstudent.Department;
                model.joiningdate = dbstudent.joiningdate;
                entities.SaveChanges();

            }
            return model;
        }

        public void DeleteStudents(int? id)
        {
            if (id.HasValue)
            {
                using (var entities = new Fresher_2019Context())
                {
                    var dbstudent = entities.Mas_Student.Where(x => x.StudentId == id).SingleOrDefault();

                    dbstudent.is_Deleted = true;
                    entities.SaveChanges();
                }
            }
        }

        public List<StudentModel> listStudents()
        {
            List<StudentModel> studentmodelList = new List<StudentModel>();
            using (var entities = new Fresher_2019Context())
            {
                var dbstudent = entities.Mas_Student.Where(x => x.is_Deleted == false).ToList();

                if (dbstudent != null)
                {
                    foreach (var item in dbstudent)
                    {
                        StudentModel stu = new StudentModel();
                        stu.StudentId = item.StudentId;
                        stu.StudentFirstName = item.StudentFirstName;
                        stu.StudentSecondName = item.StudentSecondName;
                        stu.Department = item.Department;
                        stu.Gender = item.Gender;
                        stu.joiningdate = item.joiningdate;
                        studentmodelList.Add(stu);
                    }
                }
                return studentmodelList;
            }
        }
    }
}
