﻿using FSampleStudent.Core.IServices;
using FSampleStudent.Core.Model;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FSampleStudent.Controllers.NewFolder
{
    public class StudentController : Controller
    {
        IServices _Iservices;

        public StudentController (IServices Iservices)
        {
            _Iservices = Iservices;
        }
        public IActionResult Index()
        {
            return View();
        }

        //Insert
        [HttpPost]
        public IActionResult Index(StudentModel model)
        {
            if (ModelState.IsValid)
            {
                _Iservices.saveOrEditStudents(model);
                return RedirectToAction("ListView");
            }
            return View(model);
        }

        //List
       public IActionResult ListView()
        {
            var listStudentsData = _Iservices.listStudents();
            return View(listStudentsData);
               
        }
        public IActionResult Delete(int id)
        {
            if (id < 0)
            {
                return RedirectToAction("ListView");
            }
            var dataDelete = _Iservices.DeleteOrEdit(id);
            return View(dataDelete);
        }
        [HttpPost]
        public IActionResult Delete(int? id)
        {
            if (ModelState.IsValid)
            {
                _Iservices.DeleteStudents(id);
                return RedirectToAction("ListView");
            }
            return RedirectToAction("Delete");
        }
        //Retrieve
        public IActionResult Edit(int id)
        {
            if (id < 0)
            {
                return RedirectToAction("ListView");
            }
            var dataDelete = _Iservices.DeleteOrEdit(id);
            return View(dataDelete);
        }

        //Edit
        [HttpPost]
        public IActionResult Edit(StudentModel model)
        {
            if (ModelState.IsValid)
            {
                _Iservices.saveOrEditStudents(model);
                return RedirectToAction("ListView");
            }
            return View(model);
        }
    }
}
