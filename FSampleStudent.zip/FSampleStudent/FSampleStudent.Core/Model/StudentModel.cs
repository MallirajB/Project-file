﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace FSampleStudent.Core.Model
{
    public  class StudentModel
    {

        [Key]
        public int StudentId { get; set; }
        [Required(ErrorMessage ="Please Enter the First Name")]
        [Display(Name ="Fisrt Name :")]
        public string StudentFirstName { get; set; }
        [Required(ErrorMessage = "Please Enter the Second Name")]
        [Display(Name = "Second Name :")]
        public string StudentSecondName { get; set; }
        [Required(ErrorMessage = "Please Enter the Department")]
        [Display(Name = "Department :")]
        public string Department { get; set; }
        [Required(ErrorMessage = "Please Enter the Gender")]
        [Display(Name = "Gender :")]
        public string Gender { get; set; }
        [Display(Name = "Joining Date :")]
        [DataType(DataType.Date)]
        public DateTime? joiningdate { get; set; }
        public bool? is_Deleted { get; set; }
    }
}
