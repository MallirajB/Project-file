﻿using FSampleStudent.Core.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace FSampleStudent.Core.IRepository
{
    public interface IRepository
    {
        void saveOrEditStudents(StudentModel model);
        StudentModel DeleteOrEdit(int id);
        void DeleteStudents(int? id);
        List<StudentModel> listStudents();

    }
}
