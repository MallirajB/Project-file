﻿using FSampleStudent.Core.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace FSampleStudent.Core.IServices
{
    public interface IServices
    {

        void saveOrEditStudents(StudentModel model);
        void DeleteStudents(int? id);
        List<StudentModel> listStudents();
        StudentModel DeleteOrEdit(int id);
    }
}
