﻿using FSampleStudent.Core.IRepository;
using FSampleStudent.Core.IServices;
using FSampleStudent.Core.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace FSampleStudent.Services.Service
{
    public class Service : IServices
    {
        IRepository _repository;

        public Service(IRepository repository)
        {
            _repository = repository;
        }
        public void saveOrEditStudents(StudentModel model)
        {
            _repository.saveOrEditStudents(model);

        }
        public void DeleteStudents(int? id)
        {
            _repository.DeleteStudents(id);
        }
        public List<StudentModel> listStudents()
        {
            return _repository.listStudents();
        }
        public StudentModel DeleteOrEdit(int id)
        {
            return _repository.DeleteOrEdit(id);
        }


    }
}
