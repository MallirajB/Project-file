﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WebSocketDemo.Controllers
{
   
    public class TransmitController : BaseApiController
    {
        private IConfiguration _configuration;

        public TransmitController(IConfiguration Configuration)
        {
            _configuration = Configuration;
        }

        // GET api/<TransmitController>/5
        [HttpGet]
        public async Task<IActionResult> Get(string access_token)
        {
            var context = ControllerContext.HttpContext;
            if (context.WebSockets.IsWebSocketRequest)
            {
                 System.Net.WebSockets.WebSocket wb = null;
                wb =  await context.WebSockets.AcceptWebSocketAsync();
                await Task.Run(async () =>
                {
                    while (wb.State == System.Net.WebSockets.WebSocketState.Open)
                    {
                        byte[] bt = new byte[1024];
                        System.Net.WebSockets.WebSocketReceiveResult rc = await wb.ReceiveAsync(bt, CancellationToken.None);
                        string id = System.Text.Encoding.ASCII.GetString(bt);

                        using (var connection = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
                        {
                            //connection.Open();
                            using (SqlCommand command = new SqlCommand(@"SELECT [Id],[Task],[Task_Description],[Status] FROM [dbo].[TMS_Tasks] WHERE [Id]='" + id.Trim('\0') + "' AND [Is_Deleted] =0", connection))
                            {
                                if (connection.State == ConnectionState.Closed)
                                    connection.Open();

                                SqlDataReader reader = command.ExecuteReader();

                                var listTask = reader.Cast<IDataRecord>()
                                        .Select(x => new
                                        {
                                            Id = (long)x["Id"],
                                            Task = (string)x["Task"],
                                            Task_Description = (string)x["Task_Description"],
                                            Status = (string)x["Status"]
                                        }).ToList();
                                string Statuscontent = string.Empty;
                                Statuscontent += "<table class='table table-hover table-striped table-bordered'>";
                                Statuscontent += "<thead class='thead-dark'>";
                                Statuscontent += "<tr> <th>Id</th><th>Task</th><th>Task Description</th><th>Status</th></tr>";
                                Statuscontent += "</thead>";
                                Statuscontent += "<tbody >";
                                foreach (var item in listTask)
                                {
                                    Statuscontent += "<tr><td>" + item.Id + "</td><td class='text-left'>" + item.Task + "</td><td class='text-left'>" + item.Task_Description + "</td>";
                                    if (item.Status == "New")
                                    {
                                        Statuscontent += "<td><span class='badge badge-info'>" + item.Status + "</span></td></tr>";

                                    }
                                    else if (item.Status == "Closed")
                                    {
                                        Statuscontent += "<td><span class='badge badge-secondary'>" + item.Status + "</span></td></tr>";

                                    }
                                    else if (item.Status == "Error")
                                    {
                                        Statuscontent += "<td><span class='badge badge-danger'>" + item.Status + "</span></td></tr>";

                                    }
                                    else if (item.Status == "InProgress")
                                    {
                                        Statuscontent += "<td><span class='badge badge-warning'>" + item.Status + "</span></td></tr>";

                                    }
                                    else
                                    {
                                        Statuscontent += "<td><span class='badge badge-success'>" + item.Status + "</span></td></tr>";

                                    }
                                }
                                Statuscontent += "</tbody>";
                                Statuscontent += "</table>";
                                await wb.SendAsync(System.Text.Encoding.ASCII.GetBytes(Statuscontent), System.Net.WebSockets.WebSocketMessageType.Text, true, CancellationToken.None);
                            }
                        }

                    }

                });
            }
            else
            {
                return new StatusCodeResult((int)HttpStatusCode.BadRequest);
            }
            return new EmptyResult();
        }

    }
}
