﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebSocketDemo.Middleware
{
    public class AuthenticateMiddleware
    {
        private RequestDelegate _next;
        private const string access_token = "821e2f35-86e3-4917-a963-b0c4228d1315";
        private readonly IHttpContextAccessor _httpContextAccessor;

        public AuthenticateMiddleware(RequestDelegate next, IHttpContextAccessor httpContextAccessor)
        {
            _next = next;
            _httpContextAccessor = httpContextAccessor;
        }
        public async Task Invoke(HttpContext context)
        {
            // check, if request is a TX Text Control WebSocket request
            if (context.WebSockets.IsWebSocketRequest)
            {
                // retrieve access token from query string
                //var sAccess_token = "821e2f35-86e3-4917-a963-b0c4228d1315";
                var sAccess_token = context.Request.Query["access_token"];
              var access=  _httpContextAccessor.HttpContext.Request.Headers["Authentication"];
               
                // show case only: easy comparison of tokens 
                if (sAccess_token != access_token)
                    throw new UnauthorizedAccessException();
                else
                    await _next.Invoke(context);
            }
            else if (_next != null)
            {
                await _next.Invoke(context);
            }
        }
    }

    public static class AuthenticateMiddlewareExtensions
    {
        public static IApplicationBuilder UseAuthenticateMiddleware(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<AuthenticateMiddleware>();
        }
    }
}
