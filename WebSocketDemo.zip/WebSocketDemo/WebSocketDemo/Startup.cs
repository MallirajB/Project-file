using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using WebSocketDemo.Middleware;

namespace WebSocketDemo
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddRazorPages();
            services.AddHttpContextAccessor();
            //services.TryAddSingleton<IActionContextAccessor, ActionContextAccessor>();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            app.UseWebSockets();
            app.UseAuthenticateMiddleware();
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();

            app.UseAuthorization();

            //app.UseEndpoints(endpoints =>
            //{
            //    endpoints.MapRazorPages();
            //});

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=Home}/{action=Index}/{id?}");
                endpoints.MapControllerRoute(
                  name: "Second", // Route name
                  pattern: "{controller}/{action}/{id}/{id2}"
                  );
                endpoints.MapRazorPages();
            });

           
            //app.Use(async (http, next) =>
            //{
            //    if (http.WebSockets.IsWebSocketRequest /*&& http.Request.Path == "/ws"*/)
            //    {
            //        Program.wb = await http.WebSockets.AcceptWebSocketAsync();
            //        await Task.Run(async () =>
            //        {
            //            while (Program.wb.State == System.Net.WebSockets.WebSocketState.Open)
            //            {
            //                byte[] bt = new byte[1024];
            //                System.Net.WebSockets.WebSocketReceiveResult rc = await Program.wb.ReceiveAsync(bt, CancellationToken.None);
            //                string id = System.Text.Encoding.ASCII.GetString(bt);

            //                using (var connection = new SqlConnection(Configuration.GetConnectionString("DefaultConnection")))
            //                {
            //                    //connection.Open();
            //                    using (SqlCommand command = new SqlCommand(@"SELECT [Id],[Task],[Task_Description],[Status] FROM [dbo].[TMS_Tasks] WHERE [Id]='"+ id.Trim('\0') + "' AND [Is_Deleted] =0", connection))
            //                    {
            //                        if (connection.State == ConnectionState.Closed)
            //                            connection.Open();

            //                        SqlDataReader reader = command.ExecuteReader();

            //                        var listTask = reader.Cast<IDataRecord>()
            //                                .Select(x => new
            //                                {
            //                                    Id = (long)x["Id"],
            //                                    Task = (string)x["Task"],
            //                                    Task_Description = (string)x["Task_Description"],
            //                                    Status = (string)x["Status"]
            //                                }).ToList();
            //                        string Statuscontent = string.Empty;
            //                        Statuscontent += "<table class='table table-hover table-striped table-bordered'>";
            //                        Statuscontent += "<thead class='thead-dark'>";
            //                        Statuscontent += "<tr> <th>Id</th><th>Task</th><th>Task Description</th><th>Status</th></tr>";
            //                        Statuscontent += "</thead>";
            //                        Statuscontent += "<tbody >";
            //                        foreach (var item in listTask)
            //                        {
            //                            Statuscontent += "<tr><td>" + item.Id + "</td><td class='text-left'>" + item.Task + "</td><td class='text-left'>" + item.Task_Description + "</td>";
            //                            if(item.Status=="New")
            //                            {
            //                                Statuscontent += "<td><span class='badge badge-info'>" + item.Status + "</span></td></tr>";

            //                            }
            //                            else if (item.Status == "Closed")
            //                            {
            //                                Statuscontent += "<td><span class='badge badge-secondary'>" + item.Status + "</span></td></tr>";

            //                            }
            //                            else if (item.Status == "Error")
            //                            {
            //                                Statuscontent += "<td><span class='badge badge-danger'>" + item.Status + "</span></td></tr>";

            //                            }
            //                            else if (item.Status == "InProgress")
            //                            {
            //                                Statuscontent += "<td><span class='badge badge-warning'>" + item.Status + "</span></td></tr>";

            //                            }
            //                            else
            //                            {
            //                                Statuscontent += "<td><span class='badge badge-success'>" + item.Status + "</span></td></tr>";

            //                            }
            //                        }
            //                        Statuscontent += "</tbody>";
            //                        Statuscontent += "</table>";
            //                        await Program.wb.SendAsync(System.Text.Encoding.ASCII.GetBytes(Statuscontent), System.Net.WebSockets.WebSocketMessageType.Text, true, CancellationToken.None);
            //                    }
            //                }

            //            }

            //        });
            //    }
            //    else
            //    {
            //        await next();
            //    }
            //});
        }
    }
}
