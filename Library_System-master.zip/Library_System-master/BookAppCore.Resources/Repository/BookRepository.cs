﻿using System;
using System.Collections.Generic;
using System.Text;
using BookAppCore.Core.IRepository;
using BookAppCore.Core.Model;
using System.Linq;
using BookAppCore.Entity.Library_Management_Entity;

namespace BookAppCore.Resources.Repository
{
    public class BookRepository : IRepository
    {
        #region Library User Login
        public bool UserSignin(LibraryModel libraryUser)
        {
            if (libraryUser != null)
            {
                using (var Entity = new Library_Management_SystemContext())
                {
                    var DBdata = Entity.Library_User_Deatails.Where(x => x.User_Name == libraryUser.User_Name && !x.Is_Deleted).FirstOrDefault();
                    if (DBdata != null)
                    {
                        if (DBdata.Password == libraryUser.Password)
                        {
                            return true;
                        }
                    }
                }
            }
            return false;

        }
        #endregion

        #region Get Dropdown method Info
        public List<CategoryDropdown> GetDropdown()
        {
            List<CategoryDropdown> addData = new List<CategoryDropdown>();
            using (var Entity = new Library_Management_SystemContext())
            {
                addData = (from b in Entity.Book_Category
                           where !b.Is_Deleted
                           select new CategoryDropdown
                           {
                               Category_Id = b.Category_Id,
                               Category_Name = b.Category_Name
                           }).ToList();
            }
            return addData;
        }
        #endregion

        #region Save and Update Book Data
        public void SaveOrUpdateBookDetails(BookDetailsModel GetBookDetail)
        {
            try
            {
                if (GetBookDetail != null)
                {

                    using (var Entity = new Library_Management_SystemContext())
                    {
                        Book_Details AddBookDetail = null;
                        bool isRecordExist = false;
                        AddBookDetail = Entity.Book_Details.Where(x => x.Book_Id == GetBookDetail.Book_Id).SingleOrDefault();
                        if (AddBookDetail != null)
                        {
                            isRecordExist = true;
                        }
                        else
                        {
                            AddBookDetail = new Book_Details();
                        }
                        AddBookDetail.Book_Name = GetBookDetail.Book_Name;
                        AddBookDetail.Category_Id = GetBookDetail.Category_Id;
                        AddBookDetail.Book_Author = GetBookDetail.Book_Author;
                        AddBookDetail.Book_Rate = GetBookDetail.Book_Rate;
                        AddBookDetail.Book_description = GetBookDetail.Book_description;
                        AddBookDetail.Date_Of_Relese =  Convert.ToDateTime( GetBookDetail.Date_sting);
                        AddBookDetail.Updated_Time_Stamp = DateTime.Now;

                        if (!isRecordExist)
                        {
                            AddBookDetail.Created_Time_Stamp = DateTime.Now;
                            Entity.Book_Details.Add(AddBookDetail);
                        }
                        Entity.SaveChanges();
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        #endregion

        #region List the Book Data
        public List<BookDetailsModel> ListBookDetails()
        {
            List<BookDetailsModel> bookList = new List<BookDetailsModel>();
            using(var Entity=new Library_Management_SystemContext())
            {
                var dbdata = Entity.Book_Details.Where(x => !x.Is_Deleted).ToList();
                if(dbdata.Count() > 0)
                {
                    foreach(var item in dbdata)
                    {
                        BookDetailsModel bookdetail = new BookDetailsModel();
                        bookdetail.Book_Id = item.Book_Id;
                        bookdetail.Book_Name = item.Book_Name;
                        bookdetail.Book_Author = item.Book_Author;
                        bookdetail.Category_Id = item.Category_Id;
                        if (bookdetail.Category_Id >0)
                        {
                            bookdetail.Category_Name = GetCategoryName(bookdetail.Category_Id);
                        }
                        bookdetail.Book_description = item.Book_description;
                        bookdetail.Book_Rate = item.Book_Rate;
                        bookdetail.Date_Of_Relese = item.Date_Of_Relese;
                        bookList.Add(bookdetail);
                    }
                }
            }
            return bookList.ToList();
        }
        #endregion

        #region Get data for Edit 
        public BookDetailsModel GetDetails(int BookId)
        {
            BookDetailsModel BookData = new BookDetailsModel();
            if(BookId > 0)
            {
                using(var Entity = new Library_Management_SystemContext())
                {
                    var DBdata = Entity.Book_Details.Where(x => x.Book_Id == BookId && !x.Is_Deleted).SingleOrDefault();
                    if(DBdata != null)
                    {
                        BookData.Book_Id = DBdata.Book_Id;
                        BookData.Book_Name = DBdata.Book_Name;
                        BookData.Category_Id = DBdata.Category_Id;
                        BookData.Book_Author = DBdata.Book_Author;
                        BookData.Book_description = DBdata.Book_description;
                        BookData.Book_Rate = DBdata.Book_Rate;
                        BookData.Date_sting = DBdata.Date_Of_Relese.ToString("dd-mm-yyyy");                                            
                        
                    }
                }
            }
            return BookData;
        }
        #endregion

        #region Get Category Name
        public string GetCategoryName(int CategoryId)
        {
            string CatgeoryName = string.Empty;
            if (CategoryId > 0)
            {
                using (var Entity = new Library_Management_SystemContext())
                {
                    var dbdata = Entity.Book_Category.Where(x =>x.Category_Id == CategoryId && !x.Is_Deleted).Select(x=>x.Category_Name).SingleOrDefault();
                    if (dbdata !=null)
                    {
                        CatgeoryName = dbdata;
                    }
                }
            }
           
                return CatgeoryName;
        }
        #endregion

        #region Delete Book Info
        public BookDetailsModel DeleteBookDetails(int BookId)
        {
            BookDetailsModel BookData = new BookDetailsModel();
            if(BookId>0)
            {
                using (var Entity = new Library_Management_SystemContext())
                {
                    var DBdata = Entity.Book_Details.Where(x => x.Book_Id == BookId && !x.Is_Deleted).SingleOrDefault();
                    if (BookId > 0)
                    {
                        BookData.Book_Id = DBdata.Book_Id;
                        DBdata.Is_Deleted = true;
                        Entity.SaveChanges();
                    }                  
                }
            }
            return BookData;
        }
        #endregion
    }
}
