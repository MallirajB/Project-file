﻿using System;
using System.Collections.Generic;
using System.Text;
using BookAppCore.Core.IRepository;
using BookAppCore.Core.IServices;
using BookAppCore.Core.Model;
using BookAppCore.Entity.Library_Management_Entity;

namespace BookAppCore.Services.Services
{
    public class BookService : Iservices
    {
        private IRepository _repository;
        public BookService(IRepository repository)
        {
            _repository = repository;
        }
        public bool UserSignin(LibraryModel libraryUser)
        {
          return _repository.UserSignin(libraryUser);
        }
       
        public List<CategoryDropdown> GetDropdown()
        {
           return  _repository.GetDropdown();
        }
        public void SaveOrUpdateBookDetails(BookDetailsModel GetBookDetail)
        {
            _repository.SaveOrUpdateBookDetails(GetBookDetail);
        }
        public List<BookDetailsModel> ListBookDetails()
        {
            return _repository.ListBookDetails();
        }
        public BookDetailsModel GetDetails(int BookId)
        {
            return _repository.GetDetails(BookId);
        }
        public BookDetailsModel DeleteBookDetails(int BookId)
        {
            return _repository.DeleteBookDetails(BookId);
        }
    }
}
