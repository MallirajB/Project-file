﻿using BookAppCore.Core.IRepository;
using BookAppCore.Core.IServices;
using BookAppCore.Resources.Repository;
using BookAppCore.Services.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;

namespace BookAppCore.Utilities
{
    public static class DIRSolver
    {
        public static void ConfigureServices(IServiceCollection services)
        {
            services.AddTransient<IHttpContextAccessor, HttpContextAccessor>();

            services.AddScoped<Iservices, BookService>();

            services.AddScoped<IRepository, BookRepository>();
        }
    }
}
