﻿using BookAppCore.Core.IServices;
using BookAppCore.Core.Model;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Library_System.Controllers
{
    public class LibraryController : Controller
    {
        #region Declaration
        private Iservices _Iservices;
        public  LibraryController(Iservices Iservices)
        {
            _Iservices = Iservices;
        }
        #endregion

        #region Library User Login Details
        public IActionResult SigninLibraryUser()
        {
            TempData["isLoginPage"] = true;
            return View();
        }
        [HttpPost]
        public IActionResult SigninLibraryUser(LibraryModel libraryUser)
        {
           if(libraryUser != null )
            {
                if (ModelState.IsValid)
                {
                    bool Library_User_Deatails = _Iservices.UserSignin(libraryUser);

                    if (Library_User_Deatails)
                    {
                        return RedirectToAction("ListBookDetails");
                    }
                    else
                    {
                        TempData["ErrorMessage"] = "Username And Password is Incorrect";
                    }
                }
           }
            
            return View();
        }
        #endregion

        #region DropdownButton Get Logic
        public IActionResult GetBookDetails(int? BookId)
        {
            List<CategoryDropdown> dropdownButton = new List<CategoryDropdown>();
            dropdownButton = _Iservices.GetDropdown();
            if (dropdownButton !=null && dropdownButton.Count > 0)
            {
                ViewBag.DataForDrop = dropdownButton;
            }
            
            if (BookId > 0)
            {
                var Edit = _Iservices.GetDetails(BookId ?? 0);
                return View(Edit);
            }
            else
            {
                return View();
            }         
           
        }
        #endregion

        [HttpPost]
        public IActionResult AddandUpdateBookDetails(BookDetailsModel GetBookDetail)
        {
            if(GetBookDetail != null)
            {
                _Iservices.SaveOrUpdateBookDetails(GetBookDetail);
                return RedirectToAction("ListBookDetails");
            }
            return View(GetBookDetail);
        }

        public IActionResult ListBookDetails()
        {
            var ListData = _Iservices.ListBookDetails();
            return View(ListData);
        }
        

        public IActionResult DeleteBook(int BookId)
        {
            if(BookId>0)
            {
                var Delete = _Iservices.DeleteBookDetails(BookId);
                return RedirectToAction("ListBookDetails");
            }
            else
            {
                return View();
            }
        }

    }
}
