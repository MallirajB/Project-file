﻿using BookAppCore.Core.Model;
using BookAppCore.Entity.Library_Management_Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace BookAppCore.Core.IServices
{
    public interface Iservices
    {
        bool UserSignin(LibraryModel libraryUser);
        List<CategoryDropdown> GetDropdown();
        void SaveOrUpdateBookDetails(BookDetailsModel GetBookDetail);
        List<BookDetailsModel> ListBookDetails();
        BookDetailsModel GetDetails(int BookId);
        BookDetailsModel DeleteBookDetails(int BookId);
    }
}
