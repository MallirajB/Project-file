﻿using Castle.MicroKernel.SubSystems.Conversion;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace BookAppCore.Core.Model
{
    public class LibraryModel
    {       
         [Key]        
        public string User_Name { get; set; }
        [Required(ErrorMessage = " User Name is required")]
        public string Password { get; set; }
        [Required(ErrorMessage = " Password is required")]
        public bool IsDeleted { get; set; }
    }
}
