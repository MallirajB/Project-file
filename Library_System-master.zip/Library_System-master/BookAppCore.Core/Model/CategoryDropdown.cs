﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BookAppCore.Core.Model
{
    public class CategoryDropdown
    {
        public int Category_Id { get; set; }     
        public string Category_Name { get; set; }
    }
}
