﻿using Castle.MicroKernel.SubSystems.Conversion;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace BookAppCore.Core.Model
{
    public class BookDetailsModel
    {
        public int Book_Id { get; set; }
        public int Library_User_Id { get; set; }       
        public string Book_Name { get; set; }
        public int Category_Id { get; set; }       
        public string Book_Author { get; set; }       
        public decimal Book_Rate { get; set; }        
        public string Book_description { get; set; }        
        public DateTime Date_Of_Relese { get; set; }
        public string Date_sting { get; set; }
        public DateTime Created_Time_Stamp { get; set; }
        public DateTime Updated_Time_Stamp{ get; set; }
        public string Category_Name { get; set; }


    }
}
