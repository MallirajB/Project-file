﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace staffstudent.Core.staffEntity
{
    public class Excelvalidation
    {
        public string Student_Roll_no { get; set; }
        public string Tamil { get; set; }
        public string English { get; set; }
        public string Science { get; set; }
        public string Maths { get; set; }
        public string Total { get; set; }
        public string Average { get; set; }
    }
}
