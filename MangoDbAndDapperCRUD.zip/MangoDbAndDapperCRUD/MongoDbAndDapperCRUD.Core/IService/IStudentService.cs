﻿using MongoDbAndDapperCRUD.Core.Modal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MongoDbAndDapperCRUD.Core.IService
{
  public interface IStudentService
    {
        public Student Create(Student Student);
        public List<Student> Get();
        public Student Get(string id);
        public void Update(string id, Student StudentIn);
        public void Remove(string id);
        public void Remove(Student StudentIn);
    }
}
