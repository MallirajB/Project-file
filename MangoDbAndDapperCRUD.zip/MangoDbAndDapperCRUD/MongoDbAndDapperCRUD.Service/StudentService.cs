﻿using MongoDbAndDapperCRUD.Core.IRepository;
using MongoDbAndDapperCRUD.Core.IService;
using MongoDbAndDapperCRUD.Core.Modal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MongoDbAndDapperCRUD.Service
{
   public class StudentService:IStudentService
    {
        #region Declaration
        readonly IStudentRepository _IStudentRepository;
        #endregion

        #region Constructor
        public StudentService(IStudentRepository StudentRepositories)
        {
            _IStudentRepository = StudentRepositories;
        }
        #endregion

        #region Create
        public Student Create(Student Student)
        {
            return _IStudentRepository.Create(Student);
        }
        #endregion

        #region Read
        public List<Student> Get()
        {
            return _IStudentRepository.Get();
        }
        public Student Get(string id)
        {
            return _IStudentRepository.Get(id);
        }
        #endregion


        #region Update
        public void Update(string id, Student StudentIn)
        {
            _IStudentRepository.Update(id, StudentIn);
        }
        #endregion


        #region Delete
        public void Remove(string id)
        {
            _IStudentRepository.Remove(id);
        }
        public void Remove(Student StudentIn)
        {
            _IStudentRepository.Remove(StudentIn);
        }
        #endregion

    }
}
