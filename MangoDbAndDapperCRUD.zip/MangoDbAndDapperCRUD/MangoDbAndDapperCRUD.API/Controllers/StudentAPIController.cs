﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MongoDbAndDapperCRUD.Core.IService;
using MongoDbAndDapperCRUD.Core.Modal;
using MongoDbAndDapperCRUD.Resource;
using MongoDbAndDapperCRUD.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MangoDbAndDapperCRUD.API.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class StudentAPIController : ControllerBase
    {
        #region Declaration
        private readonly IStudentService _studentService;

        public StudentAPIController(IStudentService StudentService)
        {
            _studentService = StudentService;
        }
        #endregion

        #region Get all Student details
        [HttpGet]
        public ActionResult<List<Student>> Get() =>
           _studentService.Get();
        #endregion

        #region Get Student By ID
        [HttpGet("{id:length(24)}", Name = "GetStudent")]
        public ActionResult<Student> Get(string id)
        {
            var Student = _studentService.Get(id);

            if (Student == null)
            {
                return NotFound();
            }

            return Student;
        }
        #endregion

        #region Create
        [HttpPost]
        public ActionResult<Student> Create(Student Student)
        {
            _studentService.Create(Student);

            return CreatedAtRoute("GetStudent", new { id = Student.Id.ToString() }, Student);
        }
        #endregion

        #region Update by id
        [HttpPut("{id:length(24)}")]
        public IActionResult Update(string id, Student StudentIn)
        {
            var Student = _studentService.Get(id);

            if (Student == null)
            {
                return NotFound();
            }

            _studentService.Update(id, StudentIn);

            return NoContent();
        }

        #endregion

        #region Delete By ID
        [HttpDelete("{id:length(24)}")]
        public IActionResult Delete(string id)
        {
            var Student = _studentService.Get(id);

            if (Student == null)
            {
                return NotFound();
            }

            _studentService.Remove(Student.Id);

            return NoContent();
        }
        #endregion

    }
}

