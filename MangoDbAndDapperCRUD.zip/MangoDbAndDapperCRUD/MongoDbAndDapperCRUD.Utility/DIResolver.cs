﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using MongoDbAndDapperCRUD.Core.IRepository;
using MongoDbAndDapperCRUD.Core.IService;
using MongoDbAndDapperCRUD.Resource;
using MongoDbAndDapperCRUD.Service;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MongoDbAndDapperCRUD.Utility
{
  public class DIResolver
    {
        public static void ConfigureServices(IServiceCollection services)
        {
           
            //services.AddSingleton<StudentService>();
            //services.AddSingleton<StudentRepository>();
            #region Context accesor
            // this is for accessing the http context by interface in view level
            services.AddTransient<IHttpContextAccessor, HttpContextAccessor>();
            #endregion

            #region Repository

            services.AddScoped<IStudentRepository, StudentRepository>();
            #endregion

            services.AddScoped<IStudentService, StudentService>();
          
        }
    }
}
